import os
import re
import hmac
import json
import base64
import sqlite3
import hashlib
import secrets
import urllib.request
import urllib.error
from datetime import datetime, date, timedelta
from contextlib import contextmanager

from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, field_validator

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "slotly.db")
STATIC_DIR = os.path.join(BASE_DIR, "static")

SECRET = os.environ.get("SLOTLY_SECRET")
if not SECRET:
    keyfile = os.path.join(BASE_DIR, ".secret")
    if os.path.exists(keyfile):
        with open(keyfile) as f:
            SECRET = f.read().strip()
    else:
        SECRET = secrets.token_hex(32)
        with open(keyfile, "w") as f:
            f.write(SECRET)

TOKEN_TTL = 60 * 60 * 24 * 7

ASSISTANT_KEY = os.environ.get("ASSISTANT_KEY", "sk-aitunnel-4zW7kXg3CP6GY9oeAaTB8XFGjQnhgoe5")
ASSISTANT_URL = os.environ.get("ASSISTANT_URL", "https://api.aitunnel.ru/v1/chat/completions")
ASSISTANT_MODEL = os.environ.get("ASSISTANT_MODEL", "kimi-k2.5")


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS rooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                capacity INTEGER NOT NULL,
                floor INTEGER NOT NULL,
                equipment TEXT NOT NULL,
                color TEXT NOT NULL,
                grid TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id INTEGER NOT NULL REFERENCES rooms(id),
                user_id INTEGER NOT NULL REFERENCES users(id),
                title TEXT NOT NULL,
                day TEXT NOT NULL,
                start TEXT NOT NULL,
                end TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        seed_rooms(conn)


def seed_rooms(conn):
    count = conn.execute("SELECT COUNT(*) AS c FROM rooms").fetchone()["c"]
    if count:
        return
    rooms = [
        ("Аврора", 12, 4, "Проектор, ВКС, Маркерная доска, Кондиционер", "#e11d2a", "1 / 1 / 3 / 3"),
        ("Меркурий", 4, 4, "ТВ-панель, Флипчарт", "#f0455a", "1 / 3 / 2 / 4"),
        ("Орион", 8, 4, "ВКС, ТВ-панель, Кондиционер", "#c81020", "1 / 4 / 2 / 6"),
        ("Титан", 16, 4, "Проектор, ВКС, Аудиосистема, Кондиционер", "#a50d1a", "2 / 4 / 5 / 6"),
        ("Нептун", 6, 4, "ТВ-панель, Маркерная доска", "#e2495c", "3 / 1 / 5 / 2"),
        ("Веста", 10, 3, "Проектор, ВКС, Флипчарт", "#d31f30", "1 / 1 / 3 / 3"),
        ("Гелиос", 4, 3, "ТВ-панель", "#ef5566", "1 / 3 / 2 / 5"),
        ("Атлант", 20, 3, "Проектор, ВКС, Аудиосистема, Трансляция", "#b30f1d", "2 / 4 / 5 / 6"),
        ("Феникс", 6, 3, "Флипчарт, Маркерная доска", "#e63950", "3 / 1 / 5 / 2"),
        ("Сатурн", 12, 2, "Проектор, ВКС, Кондиционер", "#e11d2a", "1 / 1 / 3 / 3"),
        ("Юпитер", 4, 2, "ТВ-панель, Флипчарт", "#f0455a", "1 / 3 / 2 / 4"),
        ("Марс", 8, 2, "ВКС, ТВ-панель", "#c81020", "1 / 4 / 2 / 6"),
        ("Комета", 14, 2, "Проектор, ВКС, Аудиосистема", "#a50d1a", "2 / 4 / 5 / 6"),
        ("Луна", 6, 2, "Маркерная доска, Флипчарт", "#e2495c", "3 / 1 / 5 / 2"),
        ("Форум", 20, 1, "Проектор, ВКС, Аудиосистема, Трансляция", "#d31f30", "1 / 1 / 3 / 3"),
        ("Атриум", 8, 1, "ТВ-панель, Кондиционер", "#ef5566", "1 / 3 / 2 / 5"),
        ("Пассаж", 4, 1, "ТВ-панель", "#b30f1d", "2 / 4 / 5 / 6"),
        ("Галерея", 10, 1, "Проектор, Флипчарт", "#e63950", "3 / 1 / 5 / 2"),
    ]
    conn.executemany(
        "INSERT INTO rooms (name, capacity, floor, equipment, color, grid) VALUES (?, ?, ?, ?, ?, ?)",
        rooms,
    )


def b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def b64d(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120000)
    return f"{b64e(salt)}${b64e(digest)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_s, digest_s = stored.split("$")
    except ValueError:
        return False
    salt = b64d(salt_s)
    expected = b64d(digest_s)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120000)
    return hmac.compare_digest(digest, expected)


def make_token(user_id: int) -> str:
    payload = {"uid": user_id, "exp": int(datetime.utcnow().timestamp()) + TOKEN_TTL}
    body = b64e(json.dumps(payload, separators=(",", ":")).encode())
    sig = b64e(hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"


def read_token(token: str):
    try:
        body, sig = token.split(".")
    except ValueError:
        return None
    expected = b64e(hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(sig, expected):
        return None
    payload = json.loads(b64d(body))
    if payload.get("exp", 0) < int(datetime.utcnow().timestamp()):
        return None
    return payload.get("uid")


app = FastAPI(title="Slotly")


@app.on_event("startup")
def startup():
    init_db()


def current_user(request: Request):
    auth = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else request.cookies.get("slotly_token", "")
    if not token:
        raise HTTPException(status_code=401, detail="Требуется авторизация")
    uid = read_token(token)
    if not uid:
        raise HTTPException(status_code=401, detail="Сессия истекла, войдите снова")
    with db() as conn:
        row = conn.execute("SELECT id, email, name FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        raise HTTPException(status_code=401, detail="Пользователь не найден")
    return dict(row)


class RegisterIn(BaseModel):
    email: EmailStr
    name: str
    password: str
    confirm: str

    @field_validator("name")
    @classmethod
    def name_ok(cls, v):
        v = v.strip()
        if len(v) < 2:
            raise ValueError("Имя должно быть не короче 2 символов")
        return v

    @field_validator("password")
    @classmethod
    def password_ok(cls, v):
        if len(v) < 6:
            raise ValueError("Пароль должен быть не короче 6 символов")
        return v


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class BookingIn(BaseModel):
    room_id: int
    title: str
    day: str
    start: str
    end: str

    @field_validator("title")
    @classmethod
    def title_ok(cls, v):
        v = v.strip()
        if len(v) < 2:
            raise ValueError("Укажите название встречи")
        return v


TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def to_minutes(t: str) -> int:
    m = TIME_RE.match(t)
    if not m:
        raise HTTPException(status_code=400, detail="Неверный формат времени")
    return int(m.group(1)) * 60 + int(m.group(2))


@app.post("/api/register")
def register(data: RegisterIn):
    if data.password != data.confirm:
        raise HTTPException(status_code=400, detail="Пароли не совпадают")
    with db() as conn:
        exists = conn.execute("SELECT id FROM users WHERE email = ?", (data.email.lower(),)).fetchone()
        if exists:
            raise HTTPException(status_code=409, detail="Аккаунт с такой почтой уже есть")
        cur = conn.execute(
            "INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)",
            (data.email.lower(), data.name.strip(), hash_password(data.password), datetime.utcnow().isoformat()),
        )
        uid = cur.lastrowid
    token = make_token(uid)
    return {"token": token, "user": {"id": uid, "email": data.email.lower(), "name": data.name.strip()}}


@app.post("/api/login")
def login(data: LoginIn):
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (data.email.lower(),)).fetchone()
    if not row or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Неверная почта или пароль")
    token = make_token(row["id"])
    return {"token": token, "user": {"id": row["id"], "email": row["email"], "name": row["name"]}}


@app.get("/api/me")
def me(user=Depends(current_user)):
    return {"user": user}


def booking_status(rows, day: str, now: datetime):
    is_today = day == now.date().isoformat()
    now_min = now.hour * 60 + now.minute
    current = None
    upcoming = 0
    for r in rows:
        s = to_minutes(r["start"])
        e = to_minutes(r["end"])
        if is_today and s <= now_min < e:
            current = r["end"]
        if not is_today or e > now_min:
            upcoming += 1
    if current:
        return {"state": "busy", "until": current, "count": len(rows)}
    if upcoming:
        return {"state": "reserved", "until": None, "count": len(rows)}
    return {"state": "free", "until": None, "count": len(rows)}


@app.get("/api/rooms")
def list_rooms(day: str = "", user=Depends(current_user)):
    if not day:
        day = date.today().isoformat()
    now = datetime.now()
    with db() as conn:
        rooms = conn.execute("SELECT * FROM rooms ORDER BY floor, id").fetchall()
        result = []
        for room in rooms:
            bks = conn.execute(
                "SELECT b.*, u.name AS user_name FROM bookings b JOIN users u ON u.id = b.user_id "
                "WHERE b.room_id = ? AND b.day = ? ORDER BY b.start",
                (room["id"], day),
            ).fetchall()
            status = booking_status(bks, day, now)
            result.append(
                {
                    "id": room["id"],
                    "name": room["name"],
                    "capacity": room["capacity"],
                    "floor": room["floor"],
                    "equipment": [e.strip() for e in room["equipment"].split(",") if e.strip()],
                    "color": room["color"],
                    "grid": room["grid"],
                    "status": status,
                    "bookings": [
                        {
                            "id": b["id"],
                            "title": b["title"],
                            "start": b["start"],
                            "end": b["end"],
                            "user_name": b["user_name"],
                            "mine": b["user_id"] == user["id"],
                        }
                        for b in bks
                    ],
                }
            )
    return {"rooms": result, "day": day}


@app.post("/api/bookings")
def create_booking(data: BookingIn, user=Depends(current_user)):
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", data.day):
        raise HTTPException(status_code=400, detail="Неверная дата")
    start = to_minutes(data.start)
    end = to_minutes(data.end)
    if end <= start:
        raise HTTPException(status_code=400, detail="Время окончания должно быть позже начала")
    if end - start < 15:
        raise HTTPException(status_code=400, detail="Минимальная длительность — 15 минут")
    today = date.today().isoformat()
    if data.day < today:
        raise HTTPException(status_code=400, detail="Нельзя бронировать прошедшую дату")
    with db() as conn:
        room = conn.execute("SELECT id FROM rooms WHERE id = ?", (data.room_id,)).fetchone()
        if not room:
            raise HTTPException(status_code=404, detail="Комната не найдена")
        clash = conn.execute(
            "SELECT b.start, b.end, u.name AS user_name FROM bookings b JOIN users u ON u.id = b.user_id "
            "WHERE b.room_id = ? AND b.day = ?",
            (data.room_id, data.day),
        ).fetchall()
        for c in clash:
            cs, ce = to_minutes(c["start"]), to_minutes(c["end"])
            if start < ce and cs < end:
                raise HTTPException(
                    status_code=409,
                    detail=f"Пересечение: {c['start']}–{c['end']} уже занято ({c['user_name']})",
                )
        cur = conn.execute(
            "INSERT INTO bookings (room_id, user_id, title, day, start, end, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (data.room_id, user["id"], data.title.strip(), data.day, data.start, data.end, datetime.utcnow().isoformat()),
        )
        bid = cur.lastrowid
    return {"id": bid, "ok": True}


@app.get("/api/bookings/my")
def my_bookings(user=Depends(current_user)):
    with db() as conn:
        rows = conn.execute(
            "SELECT b.*, r.name AS room_name, r.floor AS floor, r.color AS color "
            "FROM bookings b JOIN rooms r ON r.id = b.room_id "
            "WHERE b.user_id = ? ORDER BY b.day DESC, b.start",
            (user["id"],),
        ).fetchall()
    today = date.today().isoformat()
    now_min = datetime.now().hour * 60 + datetime.now().minute
    items = []
    for r in rows:
        past = r["day"] < today or (r["day"] == today and to_minutes(r["end"]) <= now_min)
        items.append(
            {
                "id": r["id"],
                "title": r["title"],
                "room_name": r["room_name"],
                "floor": r["floor"],
                "color": r["color"],
                "day": r["day"],
                "start": r["start"],
                "end": r["end"],
                "past": past,
            }
        )
    return {"bookings": items}


@app.delete("/api/bookings/{booking_id}")
def cancel_booking(booking_id: int, user=Depends(current_user)):
    with db() as conn:
        row = conn.execute("SELECT * FROM bookings WHERE id = ?", (booking_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Бронь не найдена")
        if row["user_id"] != user["id"]:
            raise HTTPException(status_code=403, detail="Можно отменять только свои брони")
        conn.execute("DELETE FROM bookings WHERE id = ?", (booking_id,))
    return {"ok": True}


WEEKDAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]


def assistant_context(user_id: int) -> str:
    today = date.today()
    horizon = (today + timedelta(days=14)).isoformat()
    with db() as conn:
        rooms = conn.execute("SELECT * FROM rooms ORDER BY floor, id").fetchall()
        bookings = conn.execute(
            "SELECT b.day, b.start, b.end, b.title, b.user_id, r.name AS room, r.floor AS floor "
            "FROM bookings b JOIN rooms r ON r.id = b.room_id "
            "WHERE b.day >= ? AND b.day <= ? ORDER BY b.day, r.floor, b.start",
            (today.isoformat(), horizon),
        ).fetchall()

    lines = ["ПЕРЕГОВОРНЫЕ КОМНАТЫ (всего {}):".format(len(rooms))]
    for r in rooms:
        lines.append(
            f"- {r['name']}: {r['floor']} этаж, до {r['capacity']} чел., оснащение: {r['equipment']}"
        )
    lines.append("")
    if bookings:
        lines.append("ЗАНЯТЫЕ СЛОТЫ (всё остальное время в рабочие часы свободно):")
        for b in bookings:
            mine = " — ваша бронь" if b["user_id"] == user_id else ""
            lines.append(f"- {b['room']} ({b['floor']} эт.), {b['day']} {b['start']}–{b['end']}: «{b['title']}»{mine}")
    else:
        lines.append("Занятых слотов нет — все комнаты свободны в рабочие часы на ближайшие 2 недели.")
    return "\n".join(lines)


def assistant_system_prompt(user_name: str, user_id: int) -> str:
    now = datetime.now()
    today_str = f"{now.strftime('%Y-%m-%d')} ({WEEKDAYS[now.weekday()]}), время {now.strftime('%H:%M')}"
    return (
        "Ты — Слот, дружелюбный ассистент сервиса Slotly для бронирования переговорных комнат "
        "в бизнес-центре MTS Web Services. Помогаешь сотрудникам.\n"
        f"Собеседника зовут {user_name}.\n\n"
        "Что ты умеешь:\n"
        "- подсказывать, какие комнаты свободны в нужное время и дату;\n"
        "- подбирать комнату по числу участников (по вместимости);\n"
        "- находить комнаты с нужным оснащением (проектор, ВКС, ТВ-панель, маркерная доска, "
        "флипчарт, кондиционер, аудиосистема, трансляция);\n"
        "- рассказывать про этажи, вместимость и часы работы;\n"
        "- объяснять, как забронировать.\n\n"
        "Правила:\n"
        "- Отвечай на русском, коротко и по делу, дружелюбно, уместны лёгкие эмодзи.\n"
        "- Рабочие часы бронирования: 08:00–21:00.\n"
        "- Комната свободна в интервале, если он не пересекается ни с одним её занятым слотом в эту дату.\n"
        "- Опирайся ТОЛЬКО на данные ниже. Не придумывай комнаты, оснащение или брони.\n"
        "- Если не указана дата — считай, что речь о сегодняшнем дне.\n"
        "- Сам брони не создаёшь: назови подходящую комнату и время и напомни, что забронировать "
        "можно во вкладке «Комнаты» или «3D-здание» кнопкой «Забронировать».\n"
        "- Если вопрос не про переговорные — мягко верни к теме.\n"
        f"- Сейчас: {today_str}.\n\n"
        + assistant_context(user_id)
    )


class ChatIn(BaseModel):
    messages: list


@app.post("/api/chat")
def chat(data: ChatIn, user=Depends(current_user)):
    history = []
    for m in data.messages[-12:]:
        if isinstance(m, dict) and m.get("role") in ("user", "assistant"):
            content = str(m.get("content", "")).strip()[:2000]
            if content:
                history.append({"role": m["role"], "content": content})
    if not history or history[-1]["role"] != "user":
        raise HTTPException(status_code=400, detail="Пустой запрос")

    payload = {
        "model": ASSISTANT_MODEL,
        "messages": [{"role": "system", "content": assistant_system_prompt(user["name"], user["id"])}] + history,
        "temperature": 0.4,
        "max_tokens": 1400,
    }
    req = urllib.request.Request(
        ASSISTANT_URL,
        data=json.dumps(payload).encode(),
        headers={"Authorization": "Bearer " + ASSISTANT_KEY, "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            result = json.loads(resp.read())
        reply = (result["choices"][0]["message"].get("content") or "").strip()
        if not reply:
            reply = "Не удалось сформировать ответ, попробуйте переформулировать вопрос."
        return {"reply": reply}
    except (urllib.error.URLError, urllib.error.HTTPError, KeyError, ValueError, TimeoutError):
        raise HTTPException(status_code=502, detail="Ассистент временно недоступен, попробуйте ещё раз")


@app.exception_handler(HTTPException)
def http_error(request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
