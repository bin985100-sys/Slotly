const state = {
    token: localStorage.getItem("slotly_token") || "",
    user: null,
    mode: "register",
    day: "",
    rooms: [],
    view: "rooms",
    floorFilter: "all",
    capFilter: 0,
    planFloor: null,
    selectedFloor: null,
    zoomFloor: null,
    activeRoom: null,
    chat: [],
};

const app = document.getElementById("app");
const OPEN_MIN = 8 * 60;
const CLOSE_MIN = 21 * 60;

function tpl(id) {
    return document.getElementById(id).content.firstElementChild.cloneNode(true);
}

function icon(name) {
    return `<svg class="ico"><use href="#i-${name}"></use></svg>`;
}

const EQUIP_ICONS = {
    "Проектор": "projector",
    "ВКС": "video",
    "ТВ-панель": "tv",
    "Маркерная доска": "board",
    "Флипчарт": "board",
    "Кондиционер": "ac",
    "Аудиосистема": "audio",
    "Трансляция": "cast",
};

function equipIcon(name) {
    return icon(EQUIP_ICONS[name] || "check");
}

function api(path, options = {}) {
    const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
    if (state.token) headers["Authorization"] = "Bearer " + state.token;
    return fetch(path, { ...options, headers }).then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.detail || "Что-то пошло не так");
        return data;
    });
}

function toast(message, kind = "info") {
    const stack = document.getElementById("toast-stack");
    const el = document.createElement("div");
    el.className = "toast " + kind;
    const marks = { ok: "check", err: "warn", info: "info" };
    el.innerHTML = `<span class="toast-ico">${icon(marks[kind] || "info")}</span><span>${message}</span>`;
    stack.appendChild(el);
    setTimeout(() => {
        el.classList.add("out");
        setTimeout(() => el.remove(), 400);
    }, 3400);
}

function toMin(t) {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
}

function pad(n) {
    return String(n).padStart(2, "0");
}

function isoOf(d) {
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function todayISO() {
    return isoOf(new Date());
}

function fmtMin(min) {
    return `${pad(Math.floor(min / 60))}:${pad(min % 60)}`;
}

function dayLabel(iso) {
    const today = todayISO();
    const tomorrow = isoOf(new Date(Date.now() + 86400000));
    if (iso === today) return "Сегодня";
    if (iso === tomorrow) return "Завтра";
    const d = new Date(iso + "T00:00:00");
    return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", weekday: "short" });
}

/* ---------------- Auth ---------------- */
function renderAuth() {
    app.innerHTML = "";
    const node = tpl("tpl-auth");
    app.appendChild(node);

    const form = node.querySelector('[data-form]');
    const sub = node.querySelector('[data-sub]');
    const switchBtn = node.querySelector('[data-switch]');
    const switchText = node.querySelector('[data-switch-text]');
    const label = form.querySelector('.btn-label');

    function applyMode() {
        const reg = state.mode === "register";
        sub.textContent = reg ? "Регистрация" : "Вход";
        label.textContent = reg ? "Зарегистрироваться" : "Войти";
        switchText.textContent = reg ? "Уже есть аккаунт?" : "Ещё нет аккаунта?";
        switchBtn.textContent = reg ? "Войти" : "Создать";
        node.querySelectorAll('[data-only="register"]').forEach((f) => {
            const optional = f.querySelector('input[name="name"], input[name="confirm"]');
            if (optional) {
                f.classList.toggle("collapsed", !reg);
                optional.disabled = !reg;
            }
        });
    }
    applyMode();

    switchBtn.addEventListener("click", () => {
        state.mode = state.mode === "register" ? "login" : "register";
        applyMode();
    });

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const btn = form.querySelector(".btn-primary");
        const fd = new FormData(form);
        const reg = state.mode === "register";

        if (reg && fd.get("password") !== fd.get("confirm")) {
            toast("Пароли не совпадают", "err");
            shake(form);
            return;
        }

        btn.classList.add("loading");
        try {
            const path = reg ? "/api/register" : "/api/login";
            const body = reg
                ? {
                      email: fd.get("email"),
                      name: fd.get("name"),
                      password: fd.get("password"),
                      confirm: fd.get("confirm"),
                  }
                : { email: fd.get("email"), password: fd.get("password") };
            const data = await api(path, { method: "POST", body: JSON.stringify(body) });
            state.token = data.token;
            state.user = data.user;
            localStorage.setItem("slotly_token", data.token);
            toast(reg ? "Добро пожаловать в Slotly!" : "С возвращением!", "ok");
            renderApp();
        } catch (err) {
            toast(err.message, "err");
            shake(form);
        } finally {
            btn.classList.remove("loading");
        }
    });
}

function shake(el) {
    el.animate(
        [
            { transform: "translateX(0)" },
            { transform: "translateX(-8px)" },
            { transform: "translateX(8px)" },
            { transform: "translateX(-5px)" },
            { transform: "translateX(0)" },
        ],
        { duration: 380, easing: "ease-in-out" }
    );
}

/* ---------------- App ---------------- */
async function renderApp() {
    app.innerHTML = "";
    const node = tpl("tpl-app");
    app.appendChild(node);

    node.querySelector('[data-me-name]').textContent = state.user.name;
    node.querySelector('[data-me-email]').textContent = state.user.email;
    node.querySelector('[data-avatar]').textContent = state.user.name.trim()[0].toUpperCase();

    node.querySelectorAll(".nav-item").forEach((b) => {
        b.addEventListener("click", () => setView(b.dataset.view));
    });
    node.querySelector('[data-logout]').addEventListener("click", logout);

    if (!state.day) state.day = todayISO();
    const dateInput = node.querySelector('[data-date]');
    dateInput.min = todayISO();
    dateInput.value = state.day;
    node.querySelector('[data-date-label]').textContent = dayLabel(state.day);
    dateInput.addEventListener("change", () => {
        if (dateInput.value && dateInput.value >= todayISO()) changeDay(dateInput.value);
        else dateInput.value = state.day;
    });
    node.querySelector('[data-date-prev]').addEventListener("click", () => shiftDay(-1));
    node.querySelector('[data-date-next]').addEventListener("click", () => shiftDay(1));

    setupModal();
    setupDetail();
    await loadRooms();
    setView(state.view, true);
}

function setView(view, force) {
    if (view === state.view && !force) return;
    state.view = view;
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("is-active", b.dataset.view === view));

    const titles = {
        rooms: ["Переговорные комнаты", "Выберите комнату и забронируйте свободный слот"],
        plan: ["3D-здание", "Нажмите на этаж, чтобы открыть его и выбрать комнату"],
        my: ["Мои брони", "Управляйте своими бронированиями"],
        chat: ["Ассистент", "Спросите про свободные комнаты, вместимость и оснащение"],
    };
    document.querySelector('[data-title]').textContent = titles[view][0];
    document.querySelector('[data-caption]').textContent = titles[view][1];

    const area = document.querySelector('[data-view-area]');
    area.style.opacity = "0";
    setTimeout(() => {
        area.innerHTML = "";
        if (view === "rooms") renderRooms(area);
        if (view === "plan") renderPlan(area);
        if (view === "my") renderMy(area);
        if (view === "chat") renderChat(area);
        area.style.transition = "opacity .4s ease";
        area.style.opacity = "1";
    }, 120);
}

function shiftDay(delta) {
    const d = new Date(state.day + "T00:00:00");
    d.setDate(d.getDate() + delta);
    const iso = isoOf(d);
    if (iso < todayISO()) {
        toast("Нельзя выбрать прошедшую дату", "info");
        return;
    }
    changeDay(iso);
}

async function changeDay(iso) {
    state.day = iso;
    document.querySelector('[data-date]').value = iso;
    document.querySelector('[data-date-label]').textContent = dayLabel(iso);
    await loadRooms();
    setView(state.view, true);
}

async function loadRooms() {
    try {
        const data = await api(`/api/rooms?day=${state.day}`);
        state.rooms = data.rooms;
        if (state.planFloor === null && state.rooms.length) {
            state.planFloor = state.rooms[0].floor;
        }
        updateMyCount();
    } catch (err) {
        if (String(err.message).includes("Сессия") || String(err.message).includes("авториз")) {
            logout();
        } else {
            toast(err.message, "err");
        }
    }
}

async function updateMyCount() {
    try {
        const data = await api("/api/bookings/my");
        const upcoming = data.bookings.filter((b) => !b.past).length;
        const badge = document.querySelector('[data-my-count]');
        if (badge) {
            badge.textContent = upcoming;
            badge.hidden = upcoming === 0;
        }
    } catch (_) {}
}

/* ---------------- Rooms view ---------------- */
function renderRooms(area) {
    const node = tpl("tpl-rooms");
    area.appendChild(node);

    const floors = [...new Set(state.rooms.map((r) => r.floor))].sort();
    const seg = node.querySelector('[data-floor-filter]');
    floors.forEach((f) => {
        const b = document.createElement("button");
        b.className = "seg-btn";
        b.dataset.floor = f;
        b.textContent = `${f} этаж`;
        seg.appendChild(b);
    });
    seg.querySelectorAll(".seg-btn").forEach((b) => {
        b.classList.toggle("is-active", String(state.floorFilter) === b.dataset.floor);
        b.addEventListener("click", () => {
            state.floorFilter = b.dataset.floor === "all" ? "all" : Number(b.dataset.floor);
            seg.querySelectorAll(".seg-btn").forEach((x) => x.classList.remove("is-active"));
            b.classList.add("is-active");
            paintRooms(node);
        });
    });

    node.querySelectorAll("[data-cap]").forEach((b) => {
        b.classList.toggle("is-active", Number(b.dataset.cap) === state.capFilter);
        b.addEventListener("click", () => {
            state.capFilter = Number(b.dataset.cap);
            node.querySelectorAll("[data-cap]").forEach((x) => x.classList.remove("is-active"));
            b.classList.add("is-active");
            paintRooms(node);
        });
    });

    paintRooms(node);
}

function filteredRooms() {
    return state.rooms.filter((r) => {
        if (state.floorFilter !== "all" && r.floor !== state.floorFilter) return false;
        if (r.capacity < state.capFilter) return false;
        return true;
    });
}

function paintRooms(scope) {
    const grid = scope.querySelector('[data-room-grid]');
    grid.innerHTML = "";
    const rooms = filteredRooms();
    if (!rooms.length) {
        grid.innerHTML = emptyBlock("search", "Ничего не найдено", "Попробуйте изменить фильтры");
        return;
    }
    rooms.forEach((room, i) => {
        const card = buildRoomCard(room);
        card.style.animationDelay = `${i * 55}ms`;
        grid.appendChild(card);
    });
}

function statusText(status) {
    if (status.state === "busy") return ["busy", `Занята до ${status.until}`];
    if (status.state === "reserved") return ["reserved", `Броней: ${status.count}`];
    return ["free", "Свободна"];
}

function buildRoomCard(room) {
    const card = tpl("tpl-room-card");
    card.querySelector('[data-dot]').style.background = room.color;
    card.querySelector('[data-name]').textContent = room.name;
    card.querySelector('[data-floor]').textContent = `${room.floor} этаж`;
    card.querySelector('[data-cap]').textContent = room.capacity;

    const [cls, text] = statusText(room.status);
    const pill = card.querySelector('[data-status-pill]');
    pill.className = "rc-status-pill " + cls;
    pill.textContent = text;

    const tags = card.querySelector('[data-tags]');
    room.equipment.forEach((e) => {
        const t = document.createElement("span");
        t.className = "tag";
        t.innerHTML = `${equipIcon(e)}<span>${e}</span>`;
        tags.appendChild(t);
    });

    card.querySelector('[data-timeline]').appendChild(buildTimeline(room));
    card.querySelector('[data-book]').addEventListener("click", () => openBooking(room));
    return card;
}

function buildTimeline(room) {
    const wrap = document.createElement("div");
    wrap.style.display = "flex";
    wrap.style.gap = "2px";
    wrap.style.width = "100%";
    const cells = 26;
    const span = CLOSE_MIN - OPEN_MIN;
    for (let i = 0; i < cells; i++) {
        const cell = document.createElement("div");
        cell.className = "tl-cell";
        const cellStart = OPEN_MIN + (span * i) / cells;
        const cellEnd = OPEN_MIN + (span * (i + 1)) / cells;
        for (const b of room.bookings) {
            const bs = toMin(b.start);
            const be = toMin(b.end);
            if (bs < cellEnd && cellStart < be) {
                cell.classList.add(b.mine ? "mine" : "busy");
                cell.title = `${b.start}–${b.end} · ${b.title}`;
                break;
            }
        }
        wrap.appendChild(cell);
    }
    return wrap;
}

/* ---------------- 3D building view ---------------- */
function renderPlan(area) {
    const node = tpl("tpl-plan");
    area.appendChild(node);
    state.zoomFloor = null;

    const activeFloors = [...new Set(state.rooms.map((r) => r.floor))].sort((a, b) => a - b);
    const maxFloor = Math.max(...activeFloors, 1);
    const allFloors = [];
    for (let f = 1; f <= maxFloor; f++) allFloors.push(f);

    const tabs = node.querySelector('[data-plan-floors]');
    allFloors
        .slice()
        .reverse()
        .forEach((f) => {
            const active = activeFloors.includes(f);
            const b = document.createElement("button");
            b.className = "floor-tab" + (active ? "" : " ghost");
            b.dataset.floor = f;
            b.textContent = `${f} этаж`;
            if (active) b.addEventListener("click", () => zoomFloor(f));
            tabs.appendChild(b);
        });

    const building = node.querySelector('[data-building]');
    allFloors.forEach((f, idx) => {
        building.appendChild(buildSlab(f, idx, activeFloors.includes(f)));
    });

    node.querySelector('[data-zoom-out]').addEventListener("click", unzoom);
}

function buildSlab(floor, index, active) {
    const slab = document.createElement("div");
    slab.className = "b-floor" + (active ? "" : " ghost");
    slab.style.setProperty("--i", index);
    slab.dataset.floor = floor;

    const top = document.createElement("div");
    top.className = "b-top" + (active ? "" : " ghost-top");

    if (active) {
        const mini = document.createElement("div");
        mini.className = "mini";
        state.rooms
            .filter((r) => r.floor === floor)
            .forEach((r) => {
                const cell = document.createElement("span");
                cell.className = "mini-room " + r.status.state;
                cell.style.gridArea = r.grid;
                cell.innerHTML = `<span class="mini-label">${r.name}</span>`;
                cell.addEventListener("click", (e) => {
                    if (state.zoomFloor !== floor) return;
                    e.stopPropagation();
                    openRoomDetail(r);
                });
                mini.appendChild(cell);
            });
        const stairs = document.createElement("span");
        stairs.className = "mini-stairs";
        mini.appendChild(stairs);
        top.appendChild(mini);
    }

    const badge = document.createElement("div");
    badge.className = "b-badge";
    badge.textContent = `${floor} этаж`;
    top.appendChild(badge);

    const right = document.createElement("div");
    right.className = "b-wall right";
    const front = document.createElement("div");
    front.className = "b-wall front";

    slab.append(right, front, top);

    if (active) slab.addEventListener("click", () => {
        if (state.zoomFloor === null) zoomFloor(floor);
    });
    else slab.addEventListener("click", () => toast("На этом этаже нет переговорных", "info"));

    return slab;
}

function zoomFloor(floor) {
    state.zoomFloor = floor;
    state.selectedFloor = floor;
    const stage = document.querySelector('[data-building-stage]');
    const building = document.querySelector('[data-building]');
    if (!building) return;
    stage.classList.add("zoomed");
    building.classList.add("zoomed");
    building.querySelectorAll(".b-floor").forEach((s) => {
        s.classList.toggle("focused", Number(s.dataset.floor) === floor);
    });
    document.querySelectorAll('[data-plan-floors] .floor-tab').forEach((t) => {
        t.classList.toggle("is-active", Number(t.dataset.floor) === floor);
    });
    buildRoomsPanel(floor);
}

function unzoom() {
    state.zoomFloor = null;
    const stage = document.querySelector('[data-building-stage]');
    const building = document.querySelector('[data-building]');
    if (!building) return;
    stage.classList.remove("zoomed");
    building.classList.remove("zoomed");
    building.querySelectorAll(".b-floor").forEach((s) => s.classList.remove("focused"));
    document.querySelectorAll('[data-plan-floors] .floor-tab').forEach((t) => t.classList.remove("is-active"));
    const panel = document.querySelector('[data-rooms-panel]');
    if (panel) panel.classList.remove("show");
}

function buildRoomsPanel(floor) {
    const panel = document.querySelector('[data-rooms-panel]');
    if (!panel) return;
    const body = panel.querySelector('[data-rooms-panel-body]');
    const rooms = state.rooms.filter((r) => r.floor === floor);

    panel.querySelector('[data-panel-title]').textContent = `${floor} этаж`;
    panel.querySelector('[data-panel-count]').textContent =
        `${rooms.length} ${plural(rooms.length, "переговорная", "переговорные", "переговорных")}`;

    body.innerHTML = "";
    rooms.forEach((room, i) => {
        const chip = buildRoomChip(room);
        chip.style.animationDelay = `${i * 55}ms`;
        body.appendChild(chip);
    });
    panel.classList.add("show");
}

function buildRoomChip(room) {
    const b = document.createElement("button");
    b.className = "room-chip glass-mini";
    const [cls, text] = statusText(room.status);
    b.innerHTML =
        `<span class="chip-dot" style="background:${room.color}"></span>` +
        `<span class="chip-main"><b>${room.name}</b><small>${room.capacity} мест · ${room.equipment.length} опций</small></span>` +
        `<span class="chip-status ${cls}">${text}</span>`;
    b.addEventListener("click", () => openRoomDetail(room));
    return b;
}

function plural(n, one, few, many) {
    const m10 = n % 10;
    const m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
    return many;
}

/* ---------------- My bookings ---------------- */
async function renderMy(area) {
    const node = tpl("tpl-my");
    area.appendChild(node);
    const list = node.querySelector('[data-my-list]');
    list.innerHTML = `<div class="skeleton" style="height:74px"></div><div class="skeleton" style="height:74px"></div>`;

    try {
        const data = await api("/api/bookings/my");
        list.innerHTML = "";
        if (!data.bookings.length) {
            list.innerHTML = emptyBlock("calendar", "Пока нет броней", "Забронируйте комнату во вкладке «Комнаты»");
            return;
        }
        data.bookings.forEach((b, i) => {
            const item = document.createElement("div");
            item.className = "my-item" + (b.past ? " past" : "");
            item.style.animationDelay = `${i * 50}ms`;
            item.innerHTML = `
                <span class="my-bar" style="background:${b.color}"></span>
                <div class="my-body">
                    <h4>${b.title}</h4>
                    <p>${b.room_name} · ${b.floor} этаж · ${dayLabel(b.day)}</p>
                </div>
                <div class="my-time">${b.start}<small>до ${b.end}</small></div>`;
            if (!b.past) {
                const btn = document.createElement("button");
                btn.className = "my-cancel";
                btn.textContent = "Отменить";
                btn.addEventListener("click", () => cancelBooking(b.id, item));
                item.appendChild(btn);
            }
            list.appendChild(item);
        });
    } catch (err) {
        list.innerHTML = emptyBlock("warn", "Ошибка загрузки", err.message);
    }
}

async function cancelBooking(id, row) {
    try {
        await api(`/api/bookings/${id}`, { method: "DELETE" });
        row.style.transition = "opacity .35s ease, transform .35s ease";
        row.style.opacity = "0";
        row.style.transform = "translateX(40px)";
        setTimeout(() => row.remove(), 350);
        toast("Бронь отменена", "ok");
        await loadRooms();
        updateMyCount();
    } catch (err) {
        toast(err.message, "err");
    }
}

/* ---------------- AI assistant ---------------- */
let chatBusy = false;

function renderChat(area) {
    const node = tpl("tpl-chat");
    area.appendChild(node);
    const log = node.querySelector('[data-chat-log]');
    const text = node.querySelector('[data-chat-text]');
    const form = node.querySelector('[data-chat-form]');
    const suggest = node.querySelector('[data-chat-suggest]');

    if (!state.chat.length) {
        appendMsg(
            log,
            "bot",
            `Привет, ${state.user.name}! Я Слот — ассистент Slotly. Помогу найти свободную переговорную, подобрать по числу людей или оснащению. Спросите, например: «Какие комнаты свободны в 15:00?»`,
            true
        );
    } else {
        state.chat.forEach((m) => appendMsg(log, m.role === "user" ? "user" : "bot", m.content, true));
        suggest.style.display = "none";
    }

    ["Какие комнаты свободны сейчас?", "Нужна комната на 12 человек", "Где есть проектор и ВКС?", "Как забронировать?"].forEach((p) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "suggest-chip";
        b.textContent = p;
        b.addEventListener("click", () => {
            text.value = p;
            sendChat();
        });
        suggest.appendChild(b);
    });

    const grow = () => {
        text.style.height = "auto";
        text.style.height = Math.min(text.scrollHeight, 120) + "px";
    };
    text.addEventListener("input", grow);
    text.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendChat();
        }
    });
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        sendChat();
    });

    log.scrollTop = log.scrollHeight;
    setTimeout(() => text.focus(), 120);
}

async function sendChat() {
    const view = document.querySelector(".chat-view");
    if (!view || chatBusy) return;
    const text = view.querySelector('[data-chat-text]');
    const log = view.querySelector('[data-chat-log]');
    const msg = (text.value || "").trim();
    if (!msg) return;

    chatBusy = true;
    const suggest = view.querySelector('[data-chat-suggest]');
    if (suggest) suggest.style.display = "none";

    appendMsg(log, "user", msg);
    state.chat.push({ role: "user", content: msg });
    text.value = "";
    text.style.height = "auto";

    const typing = appendTyping(log);
    try {
        const data = await api("/api/chat", { method: "POST", body: JSON.stringify({ messages: state.chat }) });
        typing.remove();
        appendMsg(log, "bot", data.reply);
        state.chat.push({ role: "assistant", content: data.reply });
    } catch (err) {
        typing.remove();
        appendMsg(log, "bot", "⚠ " + err.message);
    } finally {
        chatBusy = false;
        log.scrollTop = log.scrollHeight;
    }
}

function appendMsg(log, kind, content, instant) {
    const el = document.createElement("div");
    el.className = "msg " + kind + (instant ? " instant" : "");
    el.innerHTML = formatMsg(content);
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
}

function appendTyping(log) {
    const el = document.createElement("div");
    el.className = "msg bot typing";
    el.innerHTML = "<span></span><span></span><span></span>";
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
}

function formatMsg(raw) {
    const esc = String(raw)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    return esc.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>");
}

/* ---------------- Room detail popup ---------------- */
let detailRoot;

function setupDetail() {
    detailRoot = document.querySelector('[data-detail-root]');
    detailRoot.querySelectorAll('[data-detail-close]').forEach((el) => el.addEventListener("click", closeDetail));
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && !detailRoot.hidden) closeDetail();
    });
    detailRoot.querySelector('[data-detail-book]').addEventListener("click", () => {
        const room = state.activeRoom;
        closeDetail();
        setTimeout(() => openBooking(room), 240);
    });
}

function openRoomDetail(room) {
    state.activeRoom = room;
    detailRoot.querySelector('[data-detail-dot]').style.background = room.color;
    detailRoot.querySelector('[data-detail-name]').textContent = room.name;
    detailRoot.querySelector('[data-detail-sub]').textContent = "Переговорная комната";
    detailRoot.querySelector('[data-detail-cap]').textContent = room.capacity;
    detailRoot.querySelector('[data-detail-floor]').textContent = room.floor;
    detailRoot.querySelector('[data-detail-day]').textContent = dayLabel(state.day);

    const [cls, text] = statusText(room.status);
    detailRoot.querySelector('[data-detail-status]').innerHTML =
        `<span class="rc-status-pill ${cls}">${text}</span>`;

    const equip = detailRoot.querySelector('[data-detail-equip]');
    equip.innerHTML = "";
    room.equipment.forEach((e) => {
        const t = document.createElement("span");
        t.className = "tag";
        t.innerHTML = `${equipIcon(e)}<span>${e}</span>`;
        equip.appendChild(t);
    });

    const slots = detailRoot.querySelector('[data-detail-slots]');
    slots.innerHTML = "";
    if (room.bookings.length) {
        room.bookings.forEach((b) => {
            const line = document.createElement("div");
            line.className = "busy-line";
            line.innerHTML = `<b>${b.start}–${b.end}</b> · ${b.title}${b.mine ? " (вы)" : ""}`;
            slots.appendChild(line);
        });
    } else {
        const line = document.createElement("div");
        line.className = "busy-line";
        line.innerHTML = `${icon("check")} Весь день свободен`;
        slots.appendChild(line);
    }

    detailRoot.hidden = false;
    detailRoot.classList.remove("closing");
}

function closeDetail() {
    detailRoot.classList.add("closing");
    setTimeout(() => {
        detailRoot.hidden = true;
        detailRoot.classList.remove("closing");
    }, 300);
}

/* ---------------- Booking modal ---------------- */
let modalRoot;

function setupModal() {
    modalRoot = document.querySelector('[data-modal-root]');
    modalRoot.querySelectorAll('[data-modal-close]').forEach((el) => el.addEventListener("click", closeModal));
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && !modalRoot.hidden) closeModal();
    });

    const form = modalRoot.querySelector('[data-booking-form]');
    form.addEventListener("submit", submitBooking);
}

function openBooking(room) {
    state.activeRoom = room;
    modalRoot.querySelector('[data-modal-dot]').style.background = room.color;
    modalRoot.querySelector('[data-modal-title]').textContent = room.name;
    modalRoot.querySelector('[data-modal-sub]').textContent =
        `${room.capacity} мест · ${room.floor} этаж · ${dayLabel(state.day)}`;

    const busy = modalRoot.querySelector('[data-day-busy]');
    busy.innerHTML = "";
    if (room.bookings.length) {
        const title = document.createElement("div");
        title.className = "day-busy-title";
        title.textContent = "Занятые слоты на день:";
        busy.appendChild(title);
        room.bookings.forEach((b) => {
            const line = document.createElement("div");
            line.className = "busy-line";
            line.innerHTML = `<b>${b.start}–${b.end}</b> · ${b.title}${b.mine ? " (вы)" : ""}`;
            busy.appendChild(line);
        });
    }

    const quick = modalRoot.querySelector('[data-quick-slots]');
    quick.innerHTML = "";
    const suggestions = suggestSlots(room);
    suggestions.forEach((s) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "slot-chip";
        chip.textContent = `${s.start}–${s.end}`;
        chip.addEventListener("click", () => {
            modalRoot.querySelector('input[name="start"]').value = s.start;
            modalRoot.querySelector('input[name="end"]').value = s.end;
        });
        quick.appendChild(chip);
    });

    if (suggestions[0]) {
        modalRoot.querySelector('input[name="start"]').value = suggestions[0].start;
        modalRoot.querySelector('input[name="end"]').value = suggestions[0].end;
    }

    modalRoot.hidden = false;
    modalRoot.classList.remove("closing");
    setTimeout(() => modalRoot.querySelector('input[name="title"]').focus(), 120);
}

function suggestSlots(room) {
    const taken = room.bookings.map((b) => [toMin(b.start), toMin(b.end)]).sort((a, b) => a[0] - b[0]);
    const now = new Date();
    const isToday = state.day === todayISO();
    let cursor = OPEN_MIN;
    if (isToday) cursor = Math.max(cursor, Math.ceil((now.getHours() * 60 + now.getMinutes()) / 30) * 30);
    const free = [];
    for (const [s, e] of taken) {
        if (cursor < s && s - cursor >= 30) free.push([cursor, s]);
        cursor = Math.max(cursor, e);
    }
    if (cursor < CLOSE_MIN) free.push([cursor, CLOSE_MIN]);

    const slots = [];
    for (const [s, e] of free) {
        const end = Math.min(s + 60, e);
        if (end - s >= 30) slots.push({ start: fmtMin(s), end: fmtMin(end) });
        if (slots.length >= 4) break;
    }
    if (!slots.length) slots.push({ start: "10:00", end: "11:00" });
    return slots;
}

async function submitBooking(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const btn = form.querySelector(".btn-primary");
    const fd = new FormData(form);
    const start = fd.get("start");
    const end = fd.get("end");

    if (toMin(end) <= toMin(start)) {
        toast("Окончание должно быть позже начала", "err");
        shake(form);
        return;
    }

    btn.classList.add("loading");
    try {
        await api("/api/bookings", {
            method: "POST",
            body: JSON.stringify({
                room_id: state.activeRoom.id,
                title: fd.get("title"),
                day: state.day,
                start,
                end,
            }),
        });
        toast("Комната забронирована!", "ok");
        closeModal();
        form.reset();
        await loadRooms();
        setView(state.view, true);
        updateMyCount();
    } catch (err) {
        toast(err.message, "err");
        shake(form);
    } finally {
        btn.classList.remove("loading");
    }
}

function closeModal() {
    modalRoot.classList.add("closing");
    setTimeout(() => {
        modalRoot.hidden = true;
        modalRoot.classList.remove("closing");
    }, 300);
}

function emptyBlock(ico, title, text) {
    return `<div class="empty"><span class="empty-emoji">${icon(ico)}</span><h3>${title}</h3><p>${text}</p></div>`;
}

function logout() {
    state.token = "";
    state.user = null;
    state.chat = [];
    localStorage.removeItem("slotly_token");
    state.mode = "login";
    renderAuth();
}

async function boot() {
    if (state.token) {
        try {
            const data = await api("/api/me");
            state.user = data.user;
            await renderApp();
            return;
        } catch (_) {
            localStorage.removeItem("slotly_token");
            state.token = "";
        }
    }
    renderAuth();
}

boot();
